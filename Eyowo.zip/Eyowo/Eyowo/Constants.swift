//
//  Constants.swift
//  Eyowo
//
//  Created by Anum Ijaz on 03/08/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//
import Foundation

struct User {
    
    static let email: String = "admin@gmail.com";
    static let password: String = "1234";
    
}

struct ProductionServer {
    
    static let baseURL = "https://api.jsonbin.io"
    static let url = "/b/611a17f6d5667e403a43cdcd"
}

enum HTTPHeaderField: String {
    
    case authentication = "Authorization"
    case contentType = "Content-Type"
    case acceptType = "Accept"
    case acceptEncoding = "Accept-Encoding"
    
}

enum ContentType: String {
    
    case json = "application/json"
    
}


