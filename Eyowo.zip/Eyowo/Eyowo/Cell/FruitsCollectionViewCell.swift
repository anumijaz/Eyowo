//
//  FruitsCollectionViewCell.swift
//  Eyowo
//
//  Created by Anum Ijaz on 05/08/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//

import UIKit

class FruitsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var FruitList: UIImageView?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
