//
//  InAppManagerDraft.swift
//  Eyowo
//
//  Created by Anum Ijaz on 13/08/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//

import UIKit
import StoreKit
import Foundation

class InAppManagerDraft: NSObject {
    
    static let shared = InAppManagerDraft();
    weak var delegate: InAppManagerDelegate?
    var products: [SKProduct] = []
    var isTrialPurchased:Bool?
    var expirationDate:Date?
    var purchasedProduct:ProductType?
    
    var isSubscriptionAvailable:Bool = true{
        didSet(value){
            self.delegate?.subscriptionStatusUpdated(value:value);
        }
    }
    
    func startMonitoring(){
        
        SKPaymentQueue.default().add(self);
        self.updateSubscriptionStatus();
        
    }
    
    func stopMonitoring() {
        
        SKPaymentQueue.default().remove(self)
        
    }
    
    func loadProducts(){
        
        let productIdentifiers = Set<String>(ProductType.all.map({$0.rawValue}))
        let request = SKProductsRequest(productIdentifiers: productIdentifiers);
        request.delegate = self
        request.start()
        
    }
    
    func updateSubscriptionStatus() {
        
        self.checkSubscriptionAvailability({ [weak self] (isSubscribed) in
            self?.isSubscriptionAvailable = isSubscribed
        })
        
    }
    
    func checkSubscriptionAvailability(_ completionHandler: @escaping (Bool) -> Void) {
        guard let receiptUrl = Bundle.main.appStoreReceiptURL,
            let receipt = try? Data(contentsOf: receiptUrl).base64EncodedString() as AnyObject else {
                completionHandler(false)
                return}
        
//        let _ = Router.User.sendReceipt(receipt: receipt).request(baseUrl: "https://sandbox.itunes.apple.com").responseObject { (response: DataResponse<RTSubscriptionResponse>) in
//            switch response.result {
//            case .success(let value):
//                guard let expirationDate = value.expirationDate,
//                    let productId = value.productId else {completionHandler(false); return}
//                self.expirationDate = expirationDate
//                self.isTrialPurchased = value.isTrial
//                self.purchasedProduct = ProductType(rawValue: productId)
//                completionHandler(Date().timeIntervalSince1970 < expirationDate.timeIntervalSince1970)
//            case .failure(let error):
//                completionHandler(false)
//            }
//        }
    }
    
    
    func purchaseProduct(productType: ProductType) {
        guard let product = self.products.filter({$0.productIdentifier == productType.rawValue}).first else {
            self.delegate?.inAppLoadingFailed(error: InAppErrors.noProductsAvailable)
            return
        }
        let payment = SKMutablePayment(product: product)
        SKPaymentQueue.default().add(payment)
    }
    
    func restoreSubscription() {
        SKPaymentQueue.default().restoreCompletedTransactions()
        self.delegate?.inAppLoadingStarted()
    }
    
    func paymentQueue(_ queue: SKPaymentQueue, restoreCompletedTransactionsFailedWithError error: Swift.Error) {
        self.delegate?.inAppLoadingFailed(error: error)
    }
}

//extension InAppManagerDraft: SKPaymentTransactionObserver {}
//extension InAppManagerDraft: SKProductsRequestDelegate {}
