//
//  ProductType.swift
//  Eyowo
//
//  Created by Anum Ijaz on 13/08/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//

import UIKit

enum ProductType : String {
    
    case weekly = "com.example.app.weekly";
    case monthly = "com.example.app.monthly";
    case year   = "com.example.app.yearly";
    
    static var all:[ProductType]{
        return [.weekly,.monthly,.year];
    }
}
enum InAppErrors: Swift.Error{
    
    case noSubscriptinPurchased;
    case noProductsAvailable;
    
    var localizedDescription: String {
        
        switch self{
        case .noSubscriptinPurchased:
            return "No subscription purchased"
        case .noProductsAvailable:
            return "No Product Available"
        }
    }
    
}
