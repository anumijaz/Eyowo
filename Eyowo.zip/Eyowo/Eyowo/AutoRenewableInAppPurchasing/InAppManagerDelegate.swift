//
//  InAppManagerDelegate.swift
//  Eyowo
//
//  Created by Anum Ijaz on 13/08/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//

import UIKit

protocol InAppManagerDelegate: class {
    
    func inAppLoadingStarted();
    func inAppLoadingSucceded(productType: ProductType);
    func inAppLoadingFailed(error: Swift.Error?);
    func subscriptionStatusUpdated(value: Bool);
}
