//
//  DetailFruitViewController.swift
//  Eyowo
//
//  Created by Anum Ijaz on 28/07/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//

import UIKit
import SwiftyStoreKit

class DetailFruitViewController: UIViewController, UICollectionViewDelegate , UICollectionViewDataSource {
    
    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var Fruit_image: UIImageView!
    
    @IBOutlet var Fruit_Name: UILabel!
    
    @IBOutlet var Fruit_desc: UILabel!
    
    
    @IBOutlet var activityIndicatorButton: UIActivityIndicatorView!
    
    @IBAction func ActivityIndicator(_ sender: Any) {
        
        //activityIndicatorButton.startAnimating();
    }
    var f_title:String?
    var f_detail:String?
    var f_image:String?
    var fruitList :[String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //activityIndicatorButton.hidesWhenStopped = true;
        Fruit_Name?.text=f_title!;
        Fruit_desc?.text=f_detail!;
        Fruit_image?.image=UIImage(named:f_image!);
        collectionView.delegate = self;
        collectionView.dataSource = self;
        collectionView.translatesAutoresizingMaskIntoConstraints = false;
        
//        SwiftyStoreKit.purchaseProduct("abc") { (purchaseResult) in
//
//            <#code#>
//        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fruitList!.count;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! FruitsCollectionViewCell;
        let image = fruitList![indexPath.row]
        cell.FruitList?.image = UIImage(named:image )
        cell.FruitList?.layer.cornerRadius = 30.0;
        return cell;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width , height: view.frame.height - (view.safeAreaInsets.top + view.safeAreaInsets.bottom))
    }
    
    
    
    
    
    
    
    
}
