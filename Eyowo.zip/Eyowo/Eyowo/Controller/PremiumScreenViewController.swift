//
//  PremiumScreenViewController.swift
//  Eyowo
//
//  Created by Anum Ijaz on 16/08/2021.
//  Copyright © 2021 Anum Ijaz. All rights reserved.
//

import UIKit

class PremiumScreenViewController: UIViewController {

    @IBOutlet var purchaseProduct2: UIButton!
    @IBOutlet var purchaseproduct1: UIButton!
    
    @IBAction func purchaseProduct1Pressd(_ sender: Any) {
    }
    
    
    @IBAction func purchaseProduct2Pressed(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
